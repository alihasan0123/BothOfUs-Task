words = []
remove_list = ['to','the','and','if','is','on','I','You']
remove_list = [x.lower() for x in remove_list]

with open('string.txt') as f:
    contents = f.read()

text = contents.lower()
words = text.split()

words = [word.strip('.,!;()[]') for word in words]
unique_words = []

for i in words:
    if not(i in unique_words) and not(i in remove_list):
        unique_words.append(i)

print(unique_words)